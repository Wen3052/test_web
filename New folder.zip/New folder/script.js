function revealSurprise() {
    const surpriseBox = document.getElementById("surprise-box");
    surpriseBox.classList.toggle("hidden");
    if (!surpriseBox.classList.contains("hidden")) {
        surpriseBox.style.display = "block";
    } else {
        surpriseBox.style.display = "none";
    }
}
